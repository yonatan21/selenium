/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package autotest1;

import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


/**
 *
 * @author elnatal
 */
public class Autotest1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Email: ");
        String email = reader.next(); 
        System.out.println("Password: ");
        String password = reader.next();
        method4(email, password);
    }

    public static void method1(){
        System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://www.google.com");
        
        System.out.println("page title: " + driver.getTitle());
        System.out.println("page url: " + driver.getCurrentUrl());
        System.out.println("length of the page source code: " + driver.getPageSource().toString().length());
        
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
        }
        
        driver.close();
    }
    
    public static void method2(){
        System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        driver.navigate().to("https://www.yahoo.com");
        
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
        }
        
        driver.navigate().to("https://www.google.com");
        
        driver.navigate().refresh();
        driver.navigate().back();
        driver.navigate().forward();
        
        driver.close();
    }
    
    public static void method3() {
        System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        driver.navigate().to("https://www.google.com");
        
        WebElement searchBox = driver.findElement(By.id("lst-ib"));
        WebElement searchButton = driver.findElement(By.name("btnG"));
        searchBox.sendKeys("elnatal");
        
        searchButton.click();
        
        try {
            Thread.sleep(5000);
        } catch (Exception e) {
        }
        searchBox.clear();
        
        driver.close();
        
    }
    
    public static void method4(String Email, String Password) {
        System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://www.facebook.com");
        

        WebElement email = driver.findElement(By.id("email"));
        
        email.sendKeys(Email);
        WebElement password = driver.findElement(By.id("pass"));
        
        password.sendKeys(Password);
        driver.findElement(By.id("loginbutton")).click();
        
        driver.navigate().to("https://www.facebook.com/" + Email);
        driver.findElement(By.xpath("//div[@id='fbTimelineHeadline']/div[2]/div/div/a[3]")).click();
        
        try {
                Thread.sleep(6000);
            } catch (InterruptedException e) {
                
            }
        
        WebElement Friends = driver.findElement(By.xpath("//*[@id=\"u_0_q\"]/div/a[3]/span[1]"));
        String numFriendesText = Friends.getText().toString();
        System.out.println("number of friends " + numFriendesText);
        
        int numFriends = Integer.parseInt(numFriendesText);

        
        WebElement f = driver.findElement(By.xpath("//div[@id='collection_wrapper_2356318349']/div/ul"));

        List<WebElement> friends = (List<WebElement>) f.findElements(By.tagName("li"));
        

        Actions act = new Actions(driver);
        int prevFriends = 0;

        while(prevFriends != numFriends){
                prevFriends += 20;
                WebElement lastFriends = friends.get(friends.size() -1);
                act.moveToElement(lastFriends).build().perform();
            try {
                Thread.sleep(8000);
            } catch (InterruptedException e) {
                
            }
                friends = (List<WebElement>) f.findElements(By.tagName("li"));
                System.out.println("Number of friends -> " + friends.size());
        }
        System.out.println("Number of friends -> " + friends.size());
        
        for (int i = 0; i < friends.size(); i++) {
            System.err.println(friends.get(i).getText().toString());
        }
        
        
        
//        driver.navigate().to("https://www.facebook.com/elnatal.debebe");
        
//        WebElement Friends = driver.findElement(By.xpath("//*[@id=\"u_0_q\"]/div/a[3]/span[1]"));
        System.out.println("number of friends " + friends.size());
//        friends.click();
        
        
        
        
    }
}